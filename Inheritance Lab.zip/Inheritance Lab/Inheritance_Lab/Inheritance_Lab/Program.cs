﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_Lab
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Proffessor pf = new Proffessor();
            pf.Name= "Test";
            pf.BooksPublished = 4;
            pf.print();
            Student s1 = new Student();
            s1.Name= "Test";
            s1.Percentage = 90;
            s1.display();

        }
    }


    public abstract class Person
    {
        public abstract string Name { get; set; }
        public abstract bool isOutStanding { get; set; }
        public Person()
        {

        }
        public Person(string Name)
        {
            this.Name = Name;
        }

    }
    public class Proffessor : Person
    {
        public int BooksPublished { get; set; }
        public override string Name { get; set; }
        public Proffessor()
        {

        }
        public Proffessor(string Name, int booksPublished)
        {
            BooksPublished = booksPublished;
            this.Name = Name;
        }
        public override bool isOutStanding { get; set; }
        public void print()
        {
            if (BooksPublished > 4)
            {
                isOutStanding = true;
            }
            else
            {
                isOutStanding = false;
            }
            Console.WriteLine(Name + " " + BooksPublished);
        }
    }


            public class Student : Person
            {
                public override string Name { get; set; }
                public override bool isOutStanding { get; set; }

                public int Percentage { get; set; }
                public Student() { }
                public Student(int Percentage, string Name)
                {
                    this.Percentage = Percentage;
                    this.Name = Name;

                }
                public void display()
                {
                    if (Percentage > 85)
                    {
                        isOutStanding = true;
                        Console.WriteLine("student is outstanding");
                    }
                    else
                    {
                        isOutStanding = false;
                    }

                }

            }
   }



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritancelab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            circle s1= new circle();
            rectangle s2= new rectangle();
            triangle s3 = new triangle();
            s1.Radius = 2;
            s2.lenght = 2;
            s2.breadth = 2;
            s3.bottom = 2;
            s3.height = 2;
            s1.calculate_area();
            s2.calculate_area();
            s3.calculate_area();

            Console.WriteLine($"{s1.Area}");
            Console.WriteLine($"{s2.Area}");
            Console.WriteLine($"{s3.Area}");
        }
        interface Shape
        {
            double Area { get; set; }
            void calculate_area();
        }
        class circle : Shape
        {
            public int Radius { get; set; }
            public double Area { get; set; }
            public void calculate_area()
            {
                
                Area = Math.PI * Math.Pow(Radius, 2);
            }



        }
        class rectangle : Shape
        {
            public int lenght { get; set; }
            public int breadth { get; set; }
            public double Area { get; set; }
            public void calculate_area()
            {
                Area = lenght * breadth;
            }
        }
        class triangle : Shape
        {
            public int bottom { get; set; }
            public int height { get; set; }
            public double Area { get; set; }
            public void calculate_area()
            {
                Area = 0.5 * bottom * height;
            }

        }
    }
}
